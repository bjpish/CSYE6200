import java.util.Scanner;

public class Question_two {

    public static boolean isConsecutiveFour(int[] values){
        int count = 1;
        int temp = values[0];//save the number of index 0 in array
        //For-loop start with index 1, check values[i] if equal to values[i-1]
        for(int i = 1; i < values.length; i++){
            if(values[i] == temp){//If equal, count++
                count++;
            }else{
                count = 1;
                temp = values[i];
            }

            if(count == 4){
                return true;
            }
        }
        return false;
    }
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);  // Create a Scanner object
        System.out.print("Enter the number of values:");
        int valuedigit = input.nextInt();  // Read user input
        System.out.print("Enter the number:");
        int[] array = new int[valuedigit];
        for(int i = 0;i < array.length; i++){
            array[i] = input.nextInt();
        }
        if(isConsecutiveFour(array)){
            System.out.println("The list has consecutive fours ");
        }else{
            System.out.println("The list has no consecutive fours ");
        }
        input.close();
    }
}