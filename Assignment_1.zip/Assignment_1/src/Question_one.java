import java.util.Scanner;

public class Question_one {

    /** Return true if the card number is valid */
    public static boolean isValid(long number){
        boolean valid_status = false;
        //Determine if the length of number is between 13 and 16.
        long count = getSize(number);
        if (count < 13 || count > 16){
            return false;
        }

        //Use prefixMatched method to see the prefix if is equal to 4 or 5 or 37 or 6.
        if (prefixMatched(number, 4) || prefixMatched(number, 5) ||
                prefixMatched(number, 37) || prefixMatched(number, 6)){
            valid_status = true;
        }else{
            return false;
        }

        int even = sumOfDoubleEvenPlace(number);//Sum of double even place.
        int odd = sumOfOddPlace(number);//Sum of odd place.
        //Finally, if all the sum can devided by 10, then return true.
        if((even+odd)%10 == 0){
            valid_status = true;
        }else{
            return false;//Otherwise, return false;
        }
        return valid_status;
    }

    /** Get the result from Step 2 */
    public static int sumOfDoubleEvenPlace(long number){
        int count = getSize(number);//Get the digit os card number;
        long[] array = new long[count/2];//create new array with the length is count/2;
        int i = 0;
        //get all the even place number.
        while(i < count/2){
            number /= 10;
            long num = number % 10;
            number /= 10;
            array[i] = num;
            i++;
        }
        long sum = 0;
        //For the every even place number, multiple 2 and sum together.
        for(int j = 0; j < array.length; j++){
            long temp = array[j] * 2;
            int digit = (int)temp;
            sum = sum + (long)getDigit(digit);//If the number * 2 has two digits, we need one more calculation.
        }
    return (int)sum;
    }

    /** Return this number if it is a single digit, otherwise, return the sum of the
     two digits */
    public static int getDigit(int number){
        if(number > 9){
            int second = number%10;
            int first = number/10;
            return second + first;
        }else{
            return number;
        }
    }

    /** Return sum of odd-place digits in number */
    public static int sumOfOddPlace(long number){
        int count = getSize(number);
        long[] array = new long[count/2];
        int i = 0;
        //get all the odd place number.
        while(i < count/2){
            long num = number % 10;
            number /= 100;
            array[i] = num;
            i++;
        }
        //And sum together.
        long sum = 0;
        for(int j = 0; j < array.length; j++){
            sum += array[j];
        }
        return (int)sum;
    }
    /** Return true if the digit d is a prefix for number */
    public static boolean prefixMatched(long number, int d){
        int count = 0;//The digit of prefix
        int prefix = d;
        //Get the digit of the prefix.
        while(d > 0){
            count += 1;
            d = (d / 10);
        }

        return getPrefix(number, count) == prefix;//Use getPrefix method to see if 
        //the prefix of card number equal to the prefix.

    }
    /** Return the number of digits in d */
    public static int getSize(long d){
        int count = 0;
        while(d > 0){
            count += 1;
            d = (d / 10);
        }
        return count;
    }
    /** Return the first k number of digits from number. If the number of digits in
     number is less than k, return number. */
    public static long getPrefix(long number, int k){
        int countNum = getSize(number);
        //If digit of number less than k, return number.
        if (countNum < k){
            return number;
        }
        //For-loop, get the prefix pf number.
        for (int i = 0; i < countNum - k; i++){
            number /= 10 ;
        }
        return number;
    }
    public static void main(String[] args) {
        Scanner getinput = new Scanner(System.in);  // Create a Scanner object
        System.out.print("Enter a credit card number as a long integer:");
        String card = getinput.nextLine();  // Read user input
        long cardNum = Long.parseLong(card);
        if (isValid(cardNum)){
            System.out.println(card + " is valid.");
        }else{
            System.out.println(card + " is invalid.");
        }
        getinput.close();
    }
}